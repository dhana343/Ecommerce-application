package com.example.ecommerce_config_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
